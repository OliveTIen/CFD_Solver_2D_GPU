# Contributing

Thank you for taking the time to contribute to the project. All guidelines can be found in the [Contributing](https://stotko.github.io/stdgpu/development/contributing.html) section of the documentation.
