#!/bin/bash
set -e

# Install clang-format version 10
sudo apt-get update
sudo apt-get install clang-format-10
