#!/bin/bash
set -e

# Install clang-tidy
sudo apt-get update
sudo apt-get install clang-tidy
