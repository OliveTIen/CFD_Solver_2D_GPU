#!/bin/bash
set -e

# Install cppcheck
sudo apt-get update
sudo apt-get install cppcheck
