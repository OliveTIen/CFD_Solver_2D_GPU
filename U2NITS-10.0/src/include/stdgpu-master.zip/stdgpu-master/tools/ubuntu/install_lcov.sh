#!/bin/bash
set -e

# Install lcov
sudo apt-get update
sudo apt-get install lcov
